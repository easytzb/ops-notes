#!/bin/sh
cd "$(dirname "$0")"
rpm -qa|grep dhcp|while read tty; do rpm -e ${tty}; done
rpm -ivh dhcp-3.0.5-23.el5_5.2.x86_64.rpm

rpm -qa|grep xinetd|while read tty; do rpm -e ${tty}; done
rpm -ivh xinetd-2.3.14-10.el5.x86_64.rpm

rpm -qa|grep tftp|while read tty; do rpm -e ${tty}; done
rpm -ivh tftp-server-0.49-2.el5.centos.x86_64.rpm 
rpm -ivh tftp-0.49-2.el5.centos.x86_64.rpm 

cp -f dhcpd.conf /etc/dhcpd.conf
cp -f tftp.rpmsave /etc/xinetd.d/tftp
cp -rf boot/* /tftpboot/
